ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=TUUSUARIO,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=iromero,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=iromero,ou=people,dc=securecorp,dc=local" -W
exit
