mkdir -p /pki/ca && cd /pki/ca
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:4096 -out ca.key
clear
openssl req -x509 -new -key ca.key -sha256 -days 3650   -subj "/C=ES/O=SecureCorp/CN=SecureCorp Root CA - Ismael Romero"   -addext "basicConstraints=critical,CA:TRUE"   -addext "keyUsage=critical,keyCertSign,cRLSign"   -out ca.crt
./lab.sh comprobar
mkdir -p /pki/servidor && cd /pki/servidor
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out ldap.key
cat > ldap.ext <<'EOF'
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:ldap.securecorp.local
EOF

openssl req -new -key ldap.key -subj "/C=ES/O=SecureCorp/CN=" -out ldap.csr
openssl x509 -req -in ____ -CA ____ -CAkey ____   -CAcreateserial -days 825 -sha256 -extfile ldap.ext -out ldap.crt
cd /pki/ca
openssl req -x509 -new -key ca.key -sha256 -days 3650   -subj "/C=ES/O=SecureCorp/CN=Isma Root CA - Ismael Romero"   -addext "basicConstraints=critical,CA:TRUE"   -addext "keyUsage=critical,keyCertSign,cRLSign"   -out ca.crt
cd /pki/servidor
openssl req -new -key ldap.key -subj "/C=ES/O=SecureCorp/CN=Isma" -out ldap.csr
openssl x509 -req -in ldap.csr -CA /pki/ca/ca.crt -CAkey ca.key   -CAcreateserial -days 825 -sha256 -extfile ldap.ext -out ldap.crt
openssl x509 -req -in ldap.csr -CA /pki/ca/ca.crt -CAkey /pki/ca/ca.key   -CAcreateserial -days 825 -sha256 -extfile ldap.ext -out ldap.crt
ls
clear
openssl verify -CAfile /pki/ca/ca.crt ldap.crt
openssl x509 -in ldap.crt -noout -subject -issuer 
ldif/01-ejemplo.ldif
exit
clear
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/default/slapd
exit
ls -l /etc/ldap/tls
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/default/slapd
ls
ls -a
nano /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
ls /etc/ldap/tls
chown -R openldap:openldap /etc/ldap/tls
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
chmod 600 /etc/ldap/tls
chmod 666 /etc/ldap/tls
chmod 666 /etc/ldap/tls/ldap.key
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
ls -l /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif 
nano /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif 
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif 
chown openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
chown -R openldap:openldap /etc/ldap/tls
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif 
ls -l /etc/ldap/tls
ls -l /etc/ldap
nano /etc/apparmor.d/local/usr.sbin.slapd
apparmor_parser -r /etc/apparmor.d/usr.sbin.slapd
systemctl reload apparmor
chmod 755 /etc/ldap/tls
chmod 644 /etc/ldap/tls/ca.crt /etc/ldap/tls/ldap.crt
chmod 600 /etc/ldap/tls/ldap.key
chown -R openldap:openldap /etc/ldap/tls
journalctl -u slapd -e --no-pager
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
exit
kdb5_util create -s -r SECURECORP.LOCAL
service krb5-kdc start
kadmin.local -q "addprinc lromero" 
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
kadmin.local -q "addprinc iromero" 
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
kadmin.local -q "addprinc mtorres" 
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
clear
exit
kadmin.local -q "modprinc -allow_tix mtorres"
exit
cd ldif
ls
cd /ldif
nano 03-tls.ldif 
exit
cd /
ls
ls etc/
cat krb5.conf
nano krb5.conf
exit
cd /pki/
ls
cd /
cd ldif/
ls
nano 02-tu-turno.ldif 
nano 03-tls.ldif 
exit
