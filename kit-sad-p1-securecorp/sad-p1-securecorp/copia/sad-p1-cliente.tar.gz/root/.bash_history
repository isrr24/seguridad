clear
cd /ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
nano 01-ejemplo.ldif 
nano 02-tu-turno.ldif 
nano 01-ejemplo.ldif 
nano 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
nano 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
nano 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
nano 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Ismael2026' "uid=iromero,ou=people,dc=securecorp,dc=local"
nano 01-ejemplo.ldif 
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
su lromero
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=mtorres,ou=people,dc=securecorp,dc=local" -w 'Marta2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=mtorres,ou=people,dc=securecorp,dc=local" -w 'Marta2026'
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid 10003
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=rrhh,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn=rrhh uid
ldapsearch -x -LLL   -H ldap://ldap.securecorp.local   -b "ou=groups,dc=securecorp,dc=local"   "(cn=rrhh)"   memberUid
ldapsearch -x -LLL   -H ldap://ldap.securecorp.local   -b "ou=people,dc=securecorp,dc=local"   "(&(objectClass=inetOrgPerson)(uid=*))"   uid
ldapmodify -x -H ldap://ldap.securecorp.local -D "CN=admin,DC=securecorp,DC=local" -W <<'EOF'
dn: cn=rrhh,ou=groups,dc=securecorp,dc=local
changetype: modify
add: member
member: uid=mtorres,ou=people,dc=securecorp,dc=local
member: uid=lromero,ou=people,dc=securecorp,dc=local
EOF

ldapsearch -x -LLL   -H ldap://ldap.securecorp.local   -b "cn=rrhh,ou=groups,dc=securecorp,dc=local"   "(objectClass=*)" member
ldapmodify -x -H ldap://ldap.securecorp.local   -D "CN=admin,DC=securecorp,DC=local" -W <<'EOF'
dn: cn=rrhh,ou=groups,dc=securecorp,dc=local
changetype: modify
add: member
member: uid=lromero,ou=people,dc=securecorp,dc=local
EOF

nano 02-tu-turno.ldif 
nano 01-ejemplo.ldif 
nano 02-tu-turno.ldif 
ldapmodify -x -H ldap://ldap.securecorp.local   -D "CN=admin,DC=securecorp,DC=local" -W <<'EOF'
dn: cn=rrhh,ou=groups,dc=securecorp,dc=local
changetype: modify
add: member
member: uid=lromero,ou=people,dc=securecorp,dc=local
EOF

ldapsearch -x -LLL   -H ldap://ldap.securecorp.local   -b "cn=rrhh,ou=groups,dc=securecorp,dc=local"   "(objectClass=*)" member
clear
ldapsearch -x -LLL -H ldap://ldap.securecorp.local   -b "ou=people,dc=securecorp,dc=local"   "(&(objectClass=inetOrgPerson)(uid=mtorres))" cn mail
ldapsearch -x -LLL   -H ldap://ldap.securecorp.local   -b "ou=people,dc=securecorp,dc=local"   "(objectClass=inetOrgPerson)"   cn mail
exit
clear
ldapwhoami -x -H ldaps://ldap.securecorp.local -D 
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
clear
ldapwhoami -d 1 -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026' 2>&1 | grep TLS
nano /etc/ldap/ldap.conf
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldap://ldap.securecorp.local  -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ls pki/ca
ls
exit
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldap://ldap.securecorp.local  -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
nano /etc/ldap/ldap.conf
nano /etc/ldap/ldap.conf
nano /etc/ldap/ldap.conf
nano /etc/default/slapd
exit
kinit lromero
klist 
kdestroy
kinit iromero
klist 
kinit host/web.securecorp.local
kinit host/web.securecorp.local
kvno host/web.securecorp.local
klist 
clear
exit
ls
cd /
ls
ls pki/
ls cs
ls ca
ls pki/ca
ls
ls etc/
exit
cd /pki/
ls
cd ca
ls
nano ca.crt
exit
exit
ldap search SERVIDOR
CLEAR
ldapsearch SERVIDOR
ldapsearch SecureCorp
clear
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid iromero
cd /ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
cd /ldif/
nano 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Medina2026' "uid=mmedina,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=mmedina,ou=people,dc=securecorp,dc=local" -w 'Medina2026'
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
clear
nano 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Medina2026' "uid=mmedina,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=mmedina,ou=people,dc=securecorp,dc=local" -w 'Medina2026'
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
nano 02-tu-turno.ldif 
kinit iromero
klist
clear
exit
